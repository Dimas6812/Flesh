using System.Windows;
using TourFirmApp.DataBase;

namespace TourFirmApp
{
    public partial class MainWindow : Window
    {
        public MainWindow(User user)
        {
            InitializeComponent();

            WelcomeText.Text = $"Добро пожаловать, {user.FirstName} {user.MiddleName}!";
            RoleText.Text = $"Ваша роль: {user.Role.Name}";
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            AuthWindow auth = new AuthWindow();
            auth.Show();
            Close();
        }
    }
}
