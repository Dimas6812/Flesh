using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using TourFirmApp.DataBase;

namespace TourFirmApp
{
    public partial class AuthWindow : Window
    {
        public AuthWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text.Trim();
            string password = PasswordInput.Password;

            if (login == "" || password == "")
            {
                MessageBox.Show("Введите логин и пароль.", "Авторизация",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using var db = new DBContext();

                var user = db.Users
                    .Include(u => u.Role)
                    .Include(u => u.Auth)
                    .FirstOrDefault(u => u.Auth.Login == login
                                      && u.Auth.Password == password);

                if (user == null)
                {
                    MessageBox.Show("Неверный логин или пароль.", "Авторизация",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                MainWindow main = new MainWindow(user);
                main.Show();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось подключиться к базе данных:\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
