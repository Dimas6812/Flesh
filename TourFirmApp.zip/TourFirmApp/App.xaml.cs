using System.Windows;

namespace TourFirmApp
{
    public partial class App : Application
    {
    }
}
