TourFirmApp — WPF-приложение с авторизацией (ПР 1.4), .NET 8, Visual Studio 2022.

1. Откройте TourFirmApp.csproj в Visual Studio (пакеты NuGet восстановятся сами).
2. Консоль диспетчера пакетов: выполните команду из файла DataBase/README.txt
   (подставьте свой пароль PostgreSQL) — появятся DBContext и классы таблиц.
3. Запустите приложение. Вход: admin / Admin2026 (остальные логины и пароли — в таблице authentication).
