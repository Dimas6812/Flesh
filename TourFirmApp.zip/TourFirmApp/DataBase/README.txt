Папка заполняется автоматически командой Scaffold-DbContext
(Вид -> Другие окна -> Консоль диспетчера пакетов):

Scaffold-DbContext "Server=localhost;Database=tourfirm;Port=5432;User Id=postgres;Password=ВАШ_ПАРОЛЬ" -Context DBContext -ContextDir DataBase -OutputDir DataBase Npgsql.EntityFrameworkCore.PostgreSQL

После выполнения здесь появятся класс контекста DBContext.cs и классы таблиц (16 файлов).
Этот файл можно удалить.
